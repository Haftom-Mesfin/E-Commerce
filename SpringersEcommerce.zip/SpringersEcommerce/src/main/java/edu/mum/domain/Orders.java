package edu.mum.domain;

import java.sql.Date;
import java.util.List;

import javax.persistence.*;

@Entity
public class Orders {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long orderId;
    private Date date;
    private Double totalPrice;
    private String status;


    @OneToMany(fetch = FetchType.EAGER, mappedBy = "order")
    private List<CartItem> cartItems;

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private Members member;

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }


    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Double getTotalPrice() {
        totalPrice = calculateTotalPrice();
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public List<CartItem> getCartItems() {
        return cartItems;
    }

    public void setCartItems(List<CartItem> cartItems) {
        this.cartItems = cartItems;
    }

    public Members getMember() {
        return member;
    }

    public void setMember(Members member) {
        this.member = member;
    }


    private Double calculateTotalPrice() {
        return cartItems.stream().mapToDouble((x) -> x.getAmount() * x.getProduct().getPrice()).sum();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
