package edu.mum.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import edu.mum.domain.Members;
import edu.mum.service.MemberService;
import edu.mum.service.UserCredentialsService;

@Controller
@RequestMapping({"/members"})
public class MemberController {
	
	@Autowired
	private MemberService  memberService;


	@RequestMapping(value="", method = RequestMethod.GET)
	public String listMembers(Model model) {
		model.addAttribute("members", memberService.findAll());
		return "members";
	}
	
  	@RequestMapping(value="/{id}", method = RequestMethod.GET)
	public String getMemberById(@PathVariable("id") Long id,Model model) {
		Members member = memberService.findOne(id);
		model.addAttribute("member", member);

 		return "member";
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String getAddNewMemberForm(@ModelAttribute("newMember") Members newMember) {
	   return "signup";
	}
	   
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String processAddNewMemberForm(@Valid @ModelAttribute("newMember") Members memberToBeAdded, BindingResult result) {
		String pass = memberToBeAdded.getUserCredentials().getPassword();
		String passVerif = memberToBeAdded.getUserCredentials().getVerifyPassword();
		if(!(pass.equals(passVerif))) {
			ObjectError error = new ObjectError("email","password verification failed");
			result.addError(error);
		}

		if(result.hasErrors()) {
			return "signup";
		}
		
		 memberService.saveFull(memberToBeAdded);
		 return "redirect:/login";
 
	}
	
 
}
